
import os
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from twilio.twiml.messaging_response import MessagingResponse
from openai import OpenAI

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TWILIO_NUMBER = os.getenv("TWILIO_NUMBER")
VERIFIED_NUMBERS = os.getenv("VERIFIED_NUMBERS", "").split(",")

client = OpenAI(api_key=OPENAI_API_KEY)
app = FastAPI()

@app.post("/whatsapp")
async def whatsapp_webhook(request: Request):
    form = await request.form()
    incoming_msg = form.get("Body", "")
    from_number = form.get("From", "")
    if from_number not in VERIFIED_NUMBERS:
        return JSONResponse({"error": "Number not verified for Twilio free trial."})
    resp = client.responses.create(
        model="gpt-5-mini",
        input=incoming_msg
    )
    text = ""
    for item in resp.output:
        if hasattr(item, "content"):
            for part in item.content:
                if hasattr(part, "text"):
                    text += part.text
    twilio_resp = MessagingResponse()
    twilio_resp.message(text)
    return str(twilio_resp)

@app.post("/voice")
async def voice_webhook(request: Request):
    form = await request.form()
    to_number = form.get("To", "")
    if to_number not in VERIFIED_NUMBERS:
        return JSONResponse({"error": "Number not verified for Twilio free trial."})
    twilio_resp = MessagingResponse()
    twilio_resp.message("This is a test call from GlowAtHomeBeauty Free Trial")
    return str(twilio_resp)
