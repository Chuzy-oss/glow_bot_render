#!/bin/bash
echo "ZIP package ready. Upload this ZIP to Render → New Web Service → Upload ZIP"
